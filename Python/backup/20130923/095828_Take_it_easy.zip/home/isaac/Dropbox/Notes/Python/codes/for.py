for day in range(1,8,2):
	print "Today is the ",day,"th day\n"
