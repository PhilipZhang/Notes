name = 'Philip'
if name.startswith('Phi'):
	print 'Yes, it starts with "Phi"'
if 'i' in name:
	print 'Yes, it contains the string "a"'
if name.find('ili') != -1:
	print 'Yes, it contains the string "ili"'
delimiter = '_'
mylist = ['Brazil', 'Russia', 'India', 'China']
print delimiter.join(mylist)
